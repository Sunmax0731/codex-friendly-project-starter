# ユーザーガイド

## Agent docs を確認する

1. 対象 workspace を VS Code で開く。
2. Activity Bar の `Codex Starter` を開く。
3. `Agent Docs` から `Agent Control Docs`、`Development Documentation`、`Workspace Docs` を確認し、`AGENTS.md`、`SKILL.md`、`README.md`、`Design.md`、`Architecture.md`、主要 docs、子階層 `agents/**/AGENTS.md` / `skills/**/SKILL.md` を確認する。
4. 既定設定では Markdown WebView が開く。必要に応じて右上の `Open Source` icon で編集元を開く。
5. `Agent Docs` の title action から Project Starter、`D:\AI` 既定 docs 生成、refresh を実行できる。各項目の context menu から Markdown WebView、source 表示、path copy を実行できる。

## TODO と Issue を可視化する

1. 対象 workspace を VS Code で開く。
2. Activity Bar の `Codex Starter` を開く。
3. `Work Items` で `TODO`、`Issues`、`QCDS`、`Release readiness` を確認する。既存互換の `Tasks/*.md` は通常 UI には表示しない。
4. 未完了 TODO、Issue を選択すると、該当 Markdown が Markdown WebView で開く。
5. `Work Items` の title action または Command Palette から `Codex Starter: Open Work Dashboard` を開くと、TODO、Issue、QCDS の進捗を progress bar で確認できる。
6. Dashboard 上部は、日常的に使う `Issueを起票`、`GitHub Issuesインポート`、`CodexにPrompt送信`、`選択WorkItemを開始`、`全WorkItemを開始`、`Refresh` と、初回セットアップ向けの `FirstPrompt`、`D:\AI Docs 生成`、`Issues 初期化`、`Codex CLI 確認` に分かれている。
7. Dashboard 中段の QCDS、release readiness、open items は折りたたみ可能です。Issue / TODO の priority、status、type、phase、QCDS は色付き tag で分類される。
8. `Work Items` の title action から Dashboard、Work Item Composer、refresh を実行できる。各項目の context menu から Start、Markdown WebView、source 表示、path copy を実行できる。

## Codex Flow で工程を順番に進める

Codex Flow は Work Items の上位 orchestration です。要件、設計、実装、テスト、リリース確認などの phase prompt を `.codexflow/flow.json` で管理し、前工程の `docs/handoff/latest.md` を次工程へ渡す。主経路は background runner による Codex CLI 自動実行で、VS Code Codex sidebar への clipboard handoff は手動確認しながら進めたい場合の補助経路です。

1. Dashboard の `Codex Flow 初期化`、または Command Palette の `Codex Starter: Codex Flow を初期化` を実行する。
2. `.codexflow/flow.json`、`.codexflow/state.json`、`prompts/codexflow/*.md`、`docs/handoff/template.md`、`docs/handoff/latest.md` が作成される。既存ファイルは既定で上書きされない。
3. `Codex Starter: Codex Flow Dashboard を開く` を実行する。Flow summary、progress、next phase、phase list、last run、handoff、checks を確認できる。
4. `Copy Next Prompt` は次工程 prompt を組み立てて clipboard に入れ、VS Code Codex sidebar へ貼り付ける半自動導線として使う。
5. `Run Next` は `codexFriendlyProjectStarter.codexFlowRunner` に従って実行する。既定の `background` は Codex CLI を phase ごとの新しい session として background 実行し、JSONL、final message、checks、running state、session record を保存する。
6. `Run All Pending` は background runner で pending phase を順番に実行し、失敗時は phase の `stopOnFailure` に従って停止する。`confirmBeforeCodexRun` が有効な場合も確認は開始時の1回だけで、phase ごとの追加確認は出さない。
7. phase が failed になった場合は `Repair Failed` を実行する。failed prompt、final message、checks output、Git status を含む repair prompt が生成される。修復回数の上限は phase の `retryPolicy.maxAttempts`、flow の `maxRepairAttempts`、既定値の順で決まる。
8. `Open Latest Handoff` は `docs/handoff/latest.md` を Markdown WebView で開く。各 phase は `docs/handoff/<phase-id>.md` と latest handoff を必須成果物として扱う。
9. `Stop Current Phase` は実行中 background runner の AbortController を止め、`.codexflow/state.json` に対象 phase を `cancelled` として記録する。VS Code progress notification の cancel も同じ経路を使う。
10. `Open Phase Log` は latest run の prompt、`.jsonl`、`.final.md`、`.checks.json`、launcher を選んで開く。phase 行から実行した場合は、その phase の latest run を対象にする。
11. `Open flow.json` は `.codexflow/flow.json` を source editor で開く。`Git diff summary` は branch、HEAD、status、diff stat、last commit を clipboard にコピーする。
12. phase 定義には任意の `metadata` object を追加できる。metadata は Dashboard の phase 行と phase prompt の Flow metadata に表示されるが、実行制御には使わない。
13. phase top-level optional fields として `stopOnFailure`、`retryPolicy.maxAttempts`、`handoffPath`、`logPath`、`sessionMode`、`metadata` を使える。`sessionMode` は未指定時も `new-session` で、現時点の正式対応値も `new-session` のみです。path 系 field は workspace relative path のみ許可され、絶対パス、`../`、`.git/**`、`node_modules/**` は validation error になる。
14. background runner 開始後は `.codexflow/state.json` の phase status が `running` になり、startedAt、run id、prompt / jsonl / final / checks / launcher / handoff artifact path が記録される。完了時は `succeeded` / `failed` / `cancelled` に遷移し、Dashboard でも running phase と最新 artifact を確認できる。

Flow artifacts は workspace 内に保存される。

- `.codexflow/flow.json`
- `.codexflow/state.json`
- `.codexflow/logs/<phase-id>/*.prompt.md`
- `.codexflow/logs/<phase-id>/*.jsonl`
- `.codexflow/logs/<phase-id>/*.final.md`
- `.codexflow/logs/<phase-id>/*.checks.json`
- `.codexflow/logs/<phase-id>/*.launcher.ps1`
- `docs/handoff/*.md`

Background runner cancellation: if `Stop Current Phase` is used or the VS Code progress notification is cancelled, the runner aborts the Codex CLI/check path, records the phase as `cancelled`, and keeps generated artifacts under `.codexflow/logs/<phase-id>/`.

`danger-full-access` と `git push` は既定にならない。auto commit も既定 false で、必要な場合は Flow 定義と設定で明示する。

`D:\AI` 既定 docs 生成とは別の機能です。Default Docs scaffold は `AGENTS.md`、`SKILL.md`、`docs/*.md`、`Issues/*.md`、工程別 agent / skill docs を用意するだけで、`.codexflow/` は作らない。Codex Flow を使う場合は、その後に `Codex Flow 初期化` を実行し、生成済み docs を Flow の参照 docs として使う。

## TODO / Issue から Codex に着手してもらう

1. `Work Items` または `Codex Work Dashboard` で着手したい TODO、Issue を選ぶ。
2. Dashboard の対象行にある `Start`、または Work Items Tree の inline action `Start Work Item with Codex` を押す。
3. 起動前にモデル、インテリジェンス、アクセス権限を選ぶ。設定値、Codex CLI default、候補モデル、カスタムモデル、`workspace-write` / `read-only` / `danger-full-access` を選択できる。
4. 確認ダイアログで workspace root、access、model、インテリジェンスを確認し、既定導線では `Copy & Open Codex` を選ぶ。Terminal mode の場合だけ `Run Codex` を選ぶ。
5. 既定では開始プロンプトが clipboard に入り、右側の VS Code Codex sidebar が開く。Codex 入力欄へ貼り付けて送信する。
6. prompt には選択 model に応じた `OpenAI 公式プロンプトガイド適用` section が入り、公式 URL、startup check の結果、AGENTS / SKILL の扱いが記録される。
7. Codex 側の作業完了後、TODO / Issue の checkbox、`Status`、残作業が更新されていることを `Refresh` で確認する。

## TODO / Issue を選択して Codex に渡す

1. `Codex Work Dashboard` の Open TODO / Open Issues で、処理したい行の `Select` checkbox をオンにする。
2. Dashboard 上部の `選択WorkItemを開始` を押す。
3. モデル、インテリジェンス、アクセス権限を選び、確認ダイアログで実行条件を確認する。
4. 既定では選択した TODO / Issue だけを含む開始 prompt が clipboard に入り、右側の VS Code Codex sidebar が開く。
5. Command Palette の `Codex Starter: Start Selected Work Items with Codex` から実行する場合は、QuickPick の複数選択で対象を選ぶ。
6. prompt は選択外の Work Item を勝手に完了扱いにしないよう指示する。

## TODO / Issue を一括で Codex に渡す

1. `Codex Work Dashboard` の `全WorkItemを開始`、または Command Palette の `Codex Starter: Start All Work Items with Codex` を実行する。
2. モデル、インテリジェンス、アクセス権限を選び、確認ダイアログで workspace root、access、model、インテリジェンスを確認する。
3. 必要な場合だけ既定導線では `Copy & Open Codex`、Terminal mode では `Run Codex` を選ぶ。
4. 既定では未完了 TODO、Issue の件数、優先度、QCDS tag、phase、release readiness を含む一括開始 prompt が clipboard に入り、右側の VS Code Codex sidebar が開く。
5. prompt は P0 から P4 の優先度順に処理し、完了時に TODO checkbox、Issue の `Status`、acceptance criteria、docs、tests、QCDS 証跡を同期するよう指示する。

## QCDS 状況を確認する

1. Command Palette から `Codex Starter: Open QCDS Status` を実行する。
2. 専用 WebView で Quality、Cost、Delivery、Satisfaction の各項目を確認する。各項目には grade、score、passed/expected、checks、紐づく TODO / Issue が表示される。
3. `docs/qcds-strict-metrics.json` は `dimensions` 形式と `grades` 形式のどちらも読み取る。未生成または未対応形式の場合も4観点が D- fallback として表示される。
4. Work Items tree の QCDS 配下にある `Quality`、`Cost`、`Delivery`、`Satisfaction` をクリックすると、該当項目を開いた状態で QCDS Status WebView を表示できる。
5. `Open Metrics JSON` から `docs/qcds-strict-metrics.json` を開くと、元ファイルを変更せずに整形表示される。
6. grade が `A-` 以下の観点では `改善案を調査および検討しTODOに起こす` を押すと、該当観点、grade、checks、linked work items を含む改善 Issue が作成または再利用される。
7. TODO、Issue に紐づけを追加する場合は、本文に `[QCDS:Delivery,Satisfaction]`、または metadata に `- QCDS: Delivery, Satisfaction` を追加する。

## Local Issue を管理する

1. Dashboard の `Issues 初期化`、または Command Palette から `Codex Starter: Initialize Issues Directory` を実行する。
2. `Issues/README.md` が作成または表示される。
3. Dashboard の `Issueを起票`、または `Codex Starter: Create Local Issue` を実行して Work Item Composer を開く。
4. 自然言語メモを入力して `Codexで自然言語から反映` を押すか、title、priority、type、acceptance criteria を GUI で入力する。
5. `作成して開く` で `Issues/0001-short-title.md` を作成する。
6. 同時に `TODO.md` へ Issue へのリンク付き checkbox が追加される。TODO を入口にして進捗を管理する。
7. 作成された `Issues/0001-short-title.md` を編集し、`Status` と checkbox で進捗を管理する。
8. `Codex Starter: Refresh Work Items` または Dashboard の `Refresh` で Tree View を更新する。

## GitHub Issues 取込

1. public GitHub repository を指定できる workspace を開く。
2. Dashboard の `GitHub Issuesインポート`、Work Items title action、または Command Palette の `Codex Starter: Import GitHub Issues` を実行する。
3. `owner/repo` または GitHub URL を入力する。現在の Git remote が GitHub の場合は repository 名が既定値として入る。
4. QuickPick で取り込む GitHub Issue を複数選択する。既に同じ URL が local TODO / Issue にある item は `imported` として表示される。
5. 選択した issue は Codex CLI read-only inference で title、priority、type、phase、QCDS、acceptance criteria に整理され、`Issues/*.md` と `TODO.md` に作成される。
6. 取り込まれた local Issue / TODO には GitHub Issue の個別リンクと phase tag が残る。GitHub 側の issue は作成、編集、close されない。

## 自然言語から Issue を作る

1. Dashboard の `Issueを起票`、`Codex Starter: Open Work Item Composer`、または `Codex Starter: Create Work Item from Natural Language` を実行する。
2. 作成したい内容を自然言語メモに入力する。例: `P1。リリース前にVSIX生成とQCDS evidenceを同期したい。npm test 成功とrelease docs更新を完了条件にする。`
3. `Codexで自然言語から反映` を押して、Codex CLI の read-only `codex exec` で title、priority、type、phase、QCDS、acceptance criteria を補完する。
4. 必要なら GUI 上で修正する。
5. 画像を残したい場合は、Snipping Tool などで画像を clipboard に入れ、Composer 内で `Ctrl+V` を押す。貼り付けた画像は thumbnail で確認でき、不要なものは `削除` で外せる。
6. `作成して開く` を押す。`Issues/*.md` が作成される。画像を添付した場合は `Issues/assets/<issue-stem>/` に画像ファイルが保存され、Issue Markdown の `## Attachments` に相対 image link が記録される。
7. `TODO.md` には同じ作業を指す checkbox が追加され、Issue へのリンクと `[Phase:xx]` tag が記録される。
8. Codex CLI 由来の下書きから作成した Markdown には `Draft source: codex-cli` が記録される。
9. Codex CLI がタイムアウトまたは JSON 解析に失敗した場合は、status text にローカル補完へ戻ったことが表示される。

Work Item の `Start` で Permission denied を避けたい場合は、Settings の `codexFriendlyProjectStarter.codexGitWritePolicy` を `defer` にしておく。開始プロンプトは `git add` / `git commit` / `git push` を保留し、未コミット差分、実行済み検証、ユーザーが実行すべき Git コマンドを報告する方針になる。

## Codex session と blocked follow-up を確認する

1. Work Item の `Start`、`選択WorkItemを開始`、`全WorkItemを開始`、または current prompt handoff で VS Code Codex へプロンプトを渡す。
2. 対象 project の `docs/codex-sessions.md` と `docs/codex-sessions.jsonl` に handoff 時刻、session id、prompt file、model、intelligence、access、対象 Work Item が追記される。
3. Issue から起動した場合は、その Markdown の `Codex Sessions` セクションにも同じ session 参照が追記される。
4. Codex 実行後に対象 Work Item が `closed` にならず `blocked` として残った場合は、Dashboard の `Follow-up`、または context menu の `Codex Starter: Create Blocked Follow-up Issue` を実行する。
5. 新しい `Issues/*.md` が作成され、元 Work Item、検出した blocker、evidence、解消条件が記録される。GitHub 認証、Git index lock / ACL、Chrome runtime gate、CLI PATH 不足は優先的に分類される。

## Markdown WebView で読む

1. Markdown ファイルを開くか、Agent Docs / Work Items の node を選択する。
2. `Codex Starter: Open Markdown WebView` を実行する。
3. 右上の icon button から `Open Source`、`Copy Path`、`Refresh` を実行する。絶対パスのコピーは `Codex Starter: Copy Markdown Path` または Tree item context menu からも実行できる。再読込は `Codex Starter: Refresh Markdown WebView` からも実行できる。
4. 同じ文書を再度開いた場合は既存 WebView panel が active になる。WebView 内の `Issues/*.md`、`docs/*.md`、既存互換の `Tasks/*.md` リンクをクリックして関連文書へ移動する。
5. root `AGENTS.md` / `SKILL.md` では、子階層 `agents/**/AGENTS.md` と `skills/**/SKILL.md` の統合表示も確認できる。

## D:\AI 既定 docs を生成する

1. 対象 workspace を開く。
2. Dashboard の `D:\AI Docs 生成`、または Command Palette から `Codex Starter: Scaffold D:\AI Default Docs` を実行する。
3. 分野、Repo 名、目的、上書き可否を選択する。
4. `D:\AI\AGENTS.md`、`D:\AI\SKILL.md`、`D:\AI\Common`、`D:\AI\IDEAS\<Domain>` の docs を参照元として、root docs、`docs/*.md`、`Issues/*.md`、`agents/phases/*/AGENTS.md`、`skills/*/SKILL.md`、`skills/work-types/*/SKILL.md` が生成される。
5. 生成される root `AGENTS.md` と `SKILL.md` には OpenAI 公式 latest model / prompt guidance / AGENTS.md / Skills ページの参照先が含まれる。

## FirstPrompt を生成する

Command Palette から `Codex Starter: Generate FirstPrompt` を実行し、次を選ぶ。

- 分野
- ガバナンス
- 開発手法
- 工程
- 進行速度
- Git 書き込み方針
- モデル

生成された Markdown を Codex への最初の指示として使う。

既定の運用では、生成された FirstPrompt を VS Code 内の Codex 拡張 / Codex パネルに貼り付けて作業を依頼する。`Codex Starter: Copy FirstPrompt for VS Code Codex` を使うと、選択式に生成した FirstPrompt を直接 clipboard にコピーして Codex sidebar を開ける。FirstPrompt 本文には、作業実行が VS Code Codex / Codex CLI 相当のローカル workspace agent であること、VS Code の Explorer、Source Control、Codex panel の文脈を優先すること、選択 model に合わせた OpenAI 公式 prompt guidance section が明記される。

Permission denied を避けたい場合は、Git 書き込み方針で `Git 書き込みを保留` を選ぶ。これは OS 権限を変更するものではなく、Codex に `git add` / `git commit` / `git push` を実行させず、未コミット差分とユーザーが実行すべきコマンドを報告させるための方針である。

## Webview で生成する

Command Palette から `Codex Starter: Open Project Starter` を実行する。分野、ガバナンス、開発手法、工程、進行速度、Git 書き込み方針、モデルを変更すると summary が更新され、`FirstPrompt を開く` で Markdown を開ける。summary には OpenAI 公式 prompt guidance の起動時確認状態と latest model が表示される。`VS Code Codexへコピー` または `VS Code Codexで開く` を押すと、右側の Codex パネルへ貼り付けるための FirstPrompt をクリップボードへコピーし、Codex sidebar を開く。

`IDEAS 候補` は、選択中の分野に応じて `D:\AI\IDEAS\<Domain>` と `D:\AI\<Domain>` の `created_idea_*` を確認し、文字化けを含む候補を除外して表示する。`候補を採用` を押した場合だけ Repo 名と目的に反映される。

`FirstPrompt 履歴` は workspace storage に保存される入力値の履歴です。保存対象は分野、ガバナンス、開発手法、工程、進行速度、Git 書き込み方針、モデル、Repo 名、目的で、prompt 本文は保存しない。`履歴を復元` で入力欄へ戻せる。`履歴を削除` または `Codex Starter: Clear FirstPrompt History` で削除できる。

## OpenAI 公式 prompt guidance

拡張は activation 時に OpenAI 公式の `latest-model`、`prompt-guidance?model=gpt-5.5`、Codex `AGENTS.md`、Codex `Skills` ページを確認し、取得 status、title、hash、latest model だけを extension global state に cache する。ページ本文は保存しない。取得できない場合は fallback guidance を使い、生成 prompt には fallback と記録される。

`gpt-5.5` は outcome-first と停止条件、`gpt-5.4` は出力契約と evidence gate、`gpt-5.4-mini` は明示手順と閉じた出力、`gpt-5.3-codex` 系は agentic coding、短い preamble、検証、blocked 記録を優先して prompt section を組み立てる。

## AI Agent を起動する

主導線は VS Code 内の Codex 拡張 / Codex パネルへ FirstPrompt を貼り付ける方法です。直接実行が必要な場合は次の2通りを使い分ける。

- `Codex Starter: Send FirstPrompt to VS Code Codex`: 選択式に FirstPrompt を作り、clipboard にコピーして Codex sidebar を開く。
- `Codex Starter: Send Current Prompt to VS Code Codex`: 現在開いているプロンプト、または選択範囲だけを clipboard にコピーして Codex sidebar を開く。

初回は `Codex Starter: Check Codex CLI` で CLI と補助ツールが見えることを確認する。この command は extension-launched Codex と同じ PATH 補強を使い、`codex --version`、`codex exec --help`、`skip-git-repo-check` flag、`rg.exe`、`gh.exe`、`gh auth status` を確認する。VS Code 内 PowerShell で `rg.exe` や `gh.exe` が見つからない場合は、`codexFriendlyProjectStarter.codexToolPathPrepend` に追加の配置先を入れる。

Terminal mode で `.git` を持たない作業フォルダを対象にする場合、launcher は cwd から親方向へ `.git` を探し、見つからないときだけ `codex exec` に `--skip-git-repo-check` を追加する。通常の Git repo 内で起動するときはこの flag を追加しないため、既存 repo の挙動は変わらない。

## 表示言語

VS Code の表示言語が日本語の場合、Dashboard、QCDS Status、Markdown WebView、Agent Docs Tree group、Command Palette title は日本語寄りの文言になります。未対応言語では英語に fallback し、command id と設定キーは変わりません。

## 設定

- `codexFriendlyProjectStarter.defaultDomain`: 既定分野。
- `codexFriendlyProjectStarter.includeQcdsChecklist`: FirstPrompt に QCDS ブロックを含めるか。
- `codexFriendlyProjectStarter.codexCliPath`: `codex` または CLI の絶対パス。
- `codexFriendlyProjectStarter.codexSandboxMode`: `read-only`、`workspace-write`、`danger-full-access`。
- `codexFriendlyProjectStarter.codexHandoffTarget`: 既定は `vscode-codex`。Terminal で `codex exec` を直接起動したい場合だけ `terminal` にする。
- `codexFriendlyProjectStarter.codexGitWritePolicy`: Work Item Start Prompt に入れる Git 書き込み方針。`preflight`、`defer`、`normal` を選べる。
- `codexFriendlyProjectStarter.codexModel`: 任意の model。
- `codexFriendlyProjectStarter.codexModelChoices`: Work Item Start 前に選べる model 候補。
- `codexFriendlyProjectStarter.codexReasoningEffort`: Work Item Start の既定インテリジェンス。`minimal`、`low`、`medium`、`high`、`xhigh` を選べる。
- `codexFriendlyProjectStarter.promptForCodexRunOptions`: Work Item Start 前に model、インテリジェンス、アクセス権限を選ぶか。
- `codexFriendlyProjectStarter.openAiPromptGuidanceOnStartup`: 拡張起動時に OpenAI 公式 prompt guidance を確認するか。
- `codexFriendlyProjectStarter.openAiPromptGuidanceTimeoutMs`: 公式 prompt guidance 取得 timeout。失敗時は fallback guidance を使う。
- `codexFriendlyProjectStarter.codexProfile`: 任意の profile。
- `codexFriendlyProjectStarter.codexToolPathPrepend`: extension-launched Codex PowerShell セッションで PATH 先頭に追加するディレクトリ。
- `codexFriendlyProjectStarter.useCodexForWorkItemInference`: Work Item Composer の自然言語反映で Codex CLI を使う。
- `codexFriendlyProjectStarter.githubIssueImportLimit`: GitHub Issues 取込で一度に取得する open issue 件数。
- `codexFriendlyProjectStarter.codexWorkItemInferenceTimeoutMs`: Codex CLI 下書き生成のタイムアウト。
- `codexFriendlyProjectStarter.codexFlowRunner`: Codex Flow phase の runner。`background`、`terminal`、`vscode-codex`。
- `codexFriendlyProjectStarter.codexFlowAutoCommit`: Codex Flow scaffold metadata の auto commit 方針。既定 false。push は自動実行しない。
- `codexFriendlyProjectStarter.codexFlowMaxRepairAttempts`: failed phase の repair 最大回数。既定 1。
- `codexFriendlyProjectStarter.codexFlowCheckTimeoutMs`: Codex Flow checks 1件あたりの timeout。既定 120000ms。
- `codexFriendlyProjectStarter.recordCodexSessions`: VS Code Codex handoff / Codex CLI 起動履歴を project 内の `docs/codex-sessions.*` に記録するか。
- `codexFriendlyProjectStarter.confirmBeforeCodexRun`: 実行前確認を出すか。Codex Flow の `Run All Pending` は開始時に1回だけ確認する。
- `codexFriendlyProjectStarter.markdownOpenMode`: `webview`、`source`、`sideBySide`。

## Codex Flow Package ZIP import

A Codex Flow Package is a ZIP that carries pre-implementation planning material from ChatGPT into the current VS Code workspace. It is a transport format, not a Codex input. Codex CLI is started later from the imported workspace files through Codex Flow runtime prompt generation.

Expected ZIP layout:

```text
docs/
  requirements.md
  specification.md
  design.md
  architecture.md
  test-plan.md
  handoff/latest.md
prompts/codexflow/
  00_first.md
  10_project_setup.md
  20_core_implementation.md
.codexflow/
  flow.json
  state.json
AGENTS.md
README.codexflow.md
```

The ZIP may also contain one single top-level folder, for example `my-feature-codexflow/docs/...`. The importer treats that folder as the package root. ZIPs with multiple unrelated top-level folders are invalid.

Use `Codex Friendly: Validate Codex Flow Package` when you want a dry run. Choose the ZIP file and read the `Codex Flow Package` output channel. Validation writes nothing to the workspace. It reports valid or invalid status, errors, warnings, files to import, files to skip, overwrite candidates, phase count, prompt count, and docs count.

Use `Codex Friendly: Import Codex Flow Package` when validation is clean enough to proceed. The command validates first, asks before overwriting files, backs up existing overwritten files under `.codexflow/backups/import-YYYYMMDD-HHmmss/`, extracts only allowed files, initializes missing `.codexflow/state.json` and `docs/handoff/latest.md`, and opens the Flow Dashboard. Existing `.codexflow/state.json` is preserved and is not overwritten automatically.

Allowed package paths are `docs/**`, `prompts/**`, `.codexflow/**`, `AGENTS.md`, and `README.codexflow.md`. `.codexflow/logs/**`, `.codexflow/run-prompts/**`, and `.codexflow/backups/**` are skipped. Code or executable paths are rejected, including `src/**`, `extension.js`, `package.json`, `package-lock.json`, `node_modules/**`, `.git/**`, `.github/**`, `.vscode/**`, `tests/**`, `out/**`, `dist/**`, `*.vsix`, `*.exe`, `*.dll`, `*.bat`, `*.cmd`, `*.ps1`, and `*.sh`.

After import, use `Codex Friendly: Open Codex Flow Dashboard`, then explicitly choose `Run Next Codex Flow Phase` or `Run All Codex Flow Phases`. Import never starts execution automatically. The background runner remains the primary route. VS Code Codex clipboard handoff is still available as an assisted fallback route for manual confirmation.
