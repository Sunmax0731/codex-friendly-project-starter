# リリースチェックリスト

- [ ] `npm test` が通る。
- [ ] `docs/qcds-strict-metrics.json` の全 grade が A- 以上である。
- [ ] `docs/security-privacy-checklist.md` が更新済みである。
- [ ] `docs/traceability-matrix.md` が更新済みである。
- [ ] `dist/codex-friendly-project-starter-docs.zip` が生成済みである。
- [ ] `docs/manual-test.md` にユーザー側手動確認手順がある。
- [ ] `docs/vscode-verification-guide.md` に Codex CLI 呼び出し確認手順がある。
- [ ] `docs/vsix-package-guide.md` に VSIX package と local install の確認手順がある。
- [ ] `dist/codex-friendly-project-starter-0.1.0.vsix` の生成結果、size、SHA256 が `docs/release-evidence.json` に記録されている。
- [ ] `tools/vsix-readiness.mjs` が package metadata、docs、必須 command を確認する。
- [ ] `Work Items` Tree と `Open Work Dashboard` で TODO / Issue / release readiness を確認し、legacy Task group が表示されないことを確認する。
- [ ] `Start Selected Work Items` と `Start All Work Items` の model / インテリジェンス / アクセス権限選択を確認する。
- [ ] `GitHub Issues 取込` が public GitHub Issue を local TODO / Issue に取り込み、GitHub Issue URL と phase tag を保持し、legacy Task を新規作成しないことを確認する。
- [ ] Work Item Composer で clipboard 画像を `Ctrl+V` 貼り付けし、Issue Markdown の `## Attachments` と `Issues/assets/<issue-stem>/` に保存されることを確認する。
- [ ] `docs/codex-sessions.md` / `.jsonl` と blocked follow-up Issue 作成導線を確認する。
- [ ] Codex Flow の `.codexflow/flow.json`、`state.json`、`docs/handoff/latest.md`、`.codexflow/logs/**` の扱いと、Default Docs scaffold とは別 action であることを確認する。
- [ ] `Codex Starter: Check Codex CLI` で `rg.exe`、`gh.exe`、`gh auth status` の確認手順が残っている。
- [ ] `Open QCDS Status` で QCDS current status と QCDS improvements を確認する。
- [ ] `Open Markdown WebView` で AGENTS / SKILL / TODO / Issues / docs のリンク遷移と、既存互換の `Tasks/*.md` link 解決を確認する。
- [ ] `Issues` ディレクトリの open Issue が正式リリース範囲と整合している。
- [ ] VSIX package と local install をユーザー環境で確認する。
- [ ] `git status --short --branch` が clean である。
- [ ] `main` と `origin/main` が同期している。

## v0.1.0 の扱い

GitHub prerelease はこの初期実装では作成しない。Public repo と `origin/main` の同期を完了条件にする。VSIX package は `dist/codex-friendly-project-starter-0.1.0.vsix` として生成し、ローカルインストール確認は `docs/vsix-package-guide.md` の手順でユーザー環境の手動確認に残す。

## 2026-07-05 Phase 50 release gate status

- `node --test tests/*.test.cjs` -> 93 tests passed。
- `npm run platform:gate` -> pass true。
- `npm run release:check` -> pass true。
- `npm test` -> 93 tests passed、docs ZIP 生成、QCDS `S+` / 100、platform runtime gate pass、VSIX readiness pass、closed alpha guard pass。
- `dist/codex-friendly-project-starter-docs.zip` は Phase 50 の `npm test` で再生成した。
- VSIX package 生成と local install は Phase 50 では再実施していない。`docs/release-evidence.json` の既存 VSIX evidence と `npm run release:check` の静的 readiness を参照する。
- 実 VS Code UI のクリック QA は未確認のまま残す。確認できていない `Initialize Codex Flow`、`Open Codex Flow Dashboard`、`Copy Next Prompt`、`Open Latest Handoff`、Work Dashboard の `Codex Flow` / `次工程を実行` / `全工程を実行` を completed とは扱わない。

## 2026-07-05 Phase 60 package refresh

- `npx --yes @vscode/vsce package --out dist\codex-friendly-project-starter-0.1.0.vsix` -> generated 33 files / 125237 bytes。
- SHA256 -> `1025AD7AC64D9E9E9AD5B3E9878458DB20A1C112481DFCF621AF8FFCA1B957EA`。
- `.vscodeignore` を更新し、`.codexflow/`、`prompts/`、`tmp/` が VSIX に含まれないことを確認した。
- `E:\DevEnv\VSCode\App\bin\code.cmd --install-extension ... --force` -> installed successfully。
- `code --list-extensions --show-versions` -> `sunmax0731.codex-friendly-project-starter@0.1.0` を確認した。
- 実 VS Code UI のクリック QA は未確認のまま残す。確認できていない `Initialize Codex Flow`、`Open Codex Flow Dashboard`、`Copy Next Prompt`、`Open Latest Handoff`、Work Dashboard の `Codex Flow` / `次工程を実行` / `全工程を実行` を completed とは扱わない。
